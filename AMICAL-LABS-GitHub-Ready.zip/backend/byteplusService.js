// AMICAL LABS — BytePlus Video Edit Enhanced 2.0
// Server-side only. Do not import this file from the browser.
//
// Official operator:
//   las_video_edit_enhance
// Template:
//   replace/person_replace
// Model:
//   dreamina-seedance-2-5-260628
//
// The service receives public/TOS/asset URLs from the AMICAL backend.
// It never exposes BYTEPLUS_API_KEY to the client.

const BASE_URL =
  process.env.BYTEPLUS_BASE_URL ||
  "https://operator.las.ap-southeast-1.bytepluses.com";

const OPERATOR_ID =
  process.env.BYTEPLUS_OPERATOR_ID || "las_video_edit_enhance";

const OPERATOR_VERSION =
  process.env.BYTEPLUS_OPERATOR_VERSION || "v1";

const MODEL =
  process.env.BYTEPLUS_MODEL || "dreamina-seedance-2-5-260628";

function authHeaders() {
  if (!process.env.BYTEPLUS_API_KEY) {
    throw new Error("BYTEPLUS_API_KEY is not configured on the server.");
  }
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${process.env.BYTEPLUS_API_KEY}`,
  };
}

export async function submitPersonReplacement({
  videoUrl,
  imageUrls,
  userPrompt,
  useAssetApi = false,
}) {
  if (!videoUrl) throw new Error("videoUrl is required.");
  if (!Array.isArray(imageUrls) || imageUrls.length < 1) {
    throw new Error("At least one character reference image is required.");
  }

  const body = {
    operator_id: OPERATOR_ID,
    operator_version: OPERATOR_VERSION,
    data: {
      video_url: videoUrl,
      template: { id: "replace/person_replace" },
      user_prompt: userPrompt,
      image_urls: imageUrls,
      // Set true only when the BytePlus LAS asset-library flow is enabled.
      use_asset_api: useAssetApi,
      model: MODEL,
    },
  };

  const response = await fetch(`${BASE_URL}/api/v1/submit`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`BytePlus submit failed: ${response.status} ${text}`);
  }

  return response.json();
}

export async function pollGeneration(taskId) {
  if (!taskId) throw new Error("taskId is required.");

  const response = await fetch(`${BASE_URL}/api/v1/poll`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      operator_id: OPERATOR_ID,
      operator_version: OPERATOR_VERSION,
      task_id: taskId,
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`BytePlus poll failed: ${response.status} ${text}`);
  }

  return response.json();
}
