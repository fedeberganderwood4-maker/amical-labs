# AMICAL LABS — Frontend V2 + Node bridge

Cette archive conserve le frontend AMICAL LABS comme base visuelle et ajoute uniquement le minimum nécessaire pour le déploiement Node.js et le futur branchement BytePlus. Elle ne contient aucune donnée utilisateur, clé API ou mot de passe.

## Déploiement hPanel
- Build command: `npm run build`
- Output directory: `dist`
- Install command: `npm install` (ou `npm ci` si un package-lock.json est ajouté)
- Start command: `npm start`
- Node.js: 18.18+ (ou une version LTS compatible disponible dans hPanel)

## Variables serveur
Configurer dans hPanel, jamais dans le frontend :
`BYTEPLUS_API_KEY`, `BYTEPLUS_BASE_URL`, `BYTEPLUS_OPERATOR_ID`, `BYTEPLUS_OPERATOR_VERSION`, `BYTEPLUS_MODEL`.

Ne jamais utiliser `VITE_BYTEPLUS_API_KEY`.

## API préparée
- `GET /api/health`
- `POST /api/video/replace-character`
- `GET /api/video/generation/:taskId`

Le backend appelle BytePlus LAS `las_video_edit_enhance`, template `replace/person_replace`, avec Seedance 2.5. Le navigateur ne reçoit jamais la clé BytePlus.

## Données actuelles
Ce ZIP ne remplace pas une base de données et ne contient aucun mécanisme de reset/migration destructive. Lors de l'intégration au projet Hostinger existant, conserver les comptes, crédits, personnages, vidéos et historiques existants et brancher ces routes sur les collections actuelles.
