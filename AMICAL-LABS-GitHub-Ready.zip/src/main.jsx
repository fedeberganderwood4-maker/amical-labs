import React, {useState} from "react";
import {createRoot} from "react-dom/client";
import "./styles.css";

const nav = [
  ["dashboard","Tableau de bord","⌂"],
  ["create","Créer une vidéo","✦"],
  ["characters","Mes personnages","♙"],
  ["videos","Mes vidéos","▣"],
  ["history","Historique","◷"],
  ["credits","Crédits","◇"],
  ["settings","Paramètres","⚙"]
];

const characters = [
  {name:"Alpha", img:"/alpha.png", refs:"3 références", date:"20 avr. 2025"},
  {name:"Shadow", img:"/shadow.png", refs:"3 références", date:"18 avr. 2025"},
  {name:"Neon", img:"/neon.png", refs:"3 références", date:"15 avr. 2025"},
  {name:"Ragnar", img:"/alpha.png", refs:"2 références", date:"12 avr. 2025"},
  {name:"Luna", img:"/neon.png", refs:"3 références", date:"10 avr. 2025"},
  {name:"Kairo", img:"/shadow.png", refs:"3 références", date:"8 avr. 2025"}
];

const generations = [
  {title:"Remplacement de personnage", status:"Terminé", credits:"25 crédits", img:"/hero-reference.png", time:"22 avr. 2025 · 14:32"},
  {title:"Suppression de personnages", status:"En cours", credits:"18 crédits", img:"/hero-reference.png", time:"22 avr. 2025 · 11:20"},
  {title:"Style 3D personnalisé", status:"Terminé", credits:"30 crédits", img:"/hero-reference.png", time:"21 avr. 2025 · 18:45"},
  {title:"Gaming Scene", status:"Échec", credits:"25 crédits", img:"/hero-reference.png", time:"20 avr. 2025 · 16:10"}
];

function Icon({children}){ return <span className="icon">{children}</span> }

function App(){
  const [page,setPage] = useState("dashboard");
  const [mobileMenu,setMobileMenu] = useState(false);
  const [mode,setMode] = useState("replace");

  const go = (p)=>{setPage(p); setMobileMenu(false); window.scrollTo({top:0,behavior:"smooth"})};

  return <div className="app">
    <aside className={"sidebar "+(mobileMenu?"open":"")}>
      <div className="brand">
        <img src="/logo.png" alt="AMICAL LABS"/>
      </div>
      <nav>{nav.map(([id,label,ico]) =>
        <button key={id} className={"nav-item "+(page===id?"active":"")} onClick={()=>go(id)}>
          <Icon>{ico}</Icon><span>{label}</span>
        </button>
      )}</nav>
      <div className="user-mini">
        <div className="avatar">J</div>
        <div><b>JoyBoy</b><small>Membre gratuit</small></div>
        <span>···</span>
      </div>
    </aside>

    <main className="main">
      <header className="topbar">
        <button className="mobile-menu" onClick={()=>setMobileMenu(!mobileMenu)}>☰</button>
        <div className="mobile-brand"><img src="/logo.png" alt="AMICAL LABS"/></div>
        <div className="top-actions">
          <div className="credits-pill">◇ <b>125</b> crédits</div>
          <button className="round">♧</button>
          <div className="avatar">J</div>
        </div>
      </header>

      <div className="content">
        {page==="dashboard" && <Dashboard go={go}/>}
        {page==="create" && <Create mode={mode} setMode={setMode}/>}
        {page==="characters" && <Characters/>}
        {page==="videos" && <Videos/>}
        {page==="history" && <History/>}
        {page==="credits" && <Credits/>}
        {page==="settings" && <Settings/>}
      </div>
    </main>

    <div className="mobile-nav">
      <button onClick={()=>go("dashboard")} className={page==="dashboard"?"sel":""}>⌂<small>Accueil</small></button>
      <button onClick={()=>go("create")} className={page==="create"?"sel":""}>✦<small>Créer</small></button>
      <button onClick={()=>go("characters")} className={page==="characters"?"sel":""}>♙<small>Persos</small></button>
      <button onClick={()=>go("videos")} className={page==="videos"?"sel":""}>▣<small>Vidéos</small></button>
      <button onClick={()=>setMobileMenu(true)}>☰<small>Plus</small></button>
    </div>
  </div>
}

function Dashboard({go}){
 return <section>
   <div className="hero-grid">
     <div className="hero">
       <div className="hero-copy">
         <h1>Bonjour 👋</h1>
         <h2>Prêt à créer votre prochaine vidéo ?</h2>
         <p>Transformez vos idées en vidéos incroyables avec l'IA.</p>
         <button className="gradient-btn" onClick={()=>go("create")}>Créer une vidéo <span>→</span></button>
       </div>
       <div className="hero-art"><img src="/hero-reference.png" alt="Création vidéo IA"/></div>
     </div>
     <div className="balance card">
       <span>Crédits disponibles</span>
       <strong>◇ 125</strong>
       <button className="gradient-btn small" onClick={()=>go("credits")}>Acheter des crédits</button>
     </div>
   </div>

   <div className="stats">
     <Stat icon="▣" title="Vidéos générées" value="28" trend="+12%" />
     <Stat icon="◴" title="Générations terminées" value="24" trend="+8%" />
     <Stat icon="◇" title="Crédits utilisés" value="320" trend="+16%" />
     <Stat icon="◷" title="Temps de traitement" value="4.2 min" trend="-20%" />
   </div>

   <div className="two-col">
     <Panel title="Générations récentes" link="Voir tout →" onLink={()=>go("history")}>
       {generations.slice(0,3).map((g,i)=><GenerationRow key={i} g={g}/>)}
     </Panel>
     <Panel title="Mes personnages récents" link="Voir tout →" onLink={()=>go("characters")}>
       <div className="character-strip">{characters.slice(0,3).map((c,i)=><CharacterCard key={i} c={c} compact/>)}</div>
     </Panel>
   </div>
 </section>
}

function Stat({icon,title,value,trend}){return <div className="stat card"><div className="stat-icon"><Icon>{icon}</Icon></div><div><span>{title}</span><strong>{value}</strong><em>{trend}</em></div></div>}

function Panel({title,link,onLink,children}){return <div className="panel card"><div className="panel-head"><h3>{title}</h3>{link&&<button onClick={onLink}>{link}</button>}</div>{children}</div>}

function GenerationRow({g}){
 return <div className="generation-row">
   <img src={g.img} alt=""/>
   <div className="grow"><b>{g.title}</b><small>{g.time}</small></div>
   <div className={"status "+g.status.toLowerCase().replace(" ","-")}>{g.status}</div>
   <small>{g.credits}</small>
 </div>
}

function Create({mode,setMode}){
 return <section>
   <div className="page-title"><h1>Créer une vidéo</h1><p>Choisissez le mode de création qui correspond à votre besoin.</p></div>
   <div className="mode-grid">
     <button className={"mode-card "+(mode==="replace"?"selected":"")} onClick={()=>setMode("replace")}><div className="mode-icon">♙</div><div><b>Remplacer un personnage</b><p>Remplacez un personnage dans votre vidéo par le vôtre.</p></div></button>
     <button className={"mode-card "+(mode==="keep"?"selected":"")} onClick={()=>setMode("keep")}><div className="mode-icon">♙</div><div><b>Garder uniquement mon personnage</b><p>Supprimez les autres personnages et gardez uniquement le vôtre.</p></div></button>
   </div>
   <div className="steps card">{["1. Vidéo source","2. Personnage","3. À remplacer","4. Instructions","5. Résumé"].map((s,i)=><span className={i===0?"current":""} key={s}>{s}</span>)}</div>
   <div className="studio-grid">
     <div className="panel card">
       <h3><i>1</i> Importez votre vidéo</h3><p className="muted">Glissez-déposez votre vidéo ici ou sélectionnez un fichier</p>
       <div className="upload"><div className="upload-icon">↑</div><button className="gradient-btn">Choisir une vidéo</button><small>Formats acceptés : MP4, MOV, AVI</small></div>
     </div>
     <div className="tips card"><h3>Astuces</h3><p>✓ Utilisez une vidéo de bonne qualité</p><p>✓ Évitez les vidéos trop courtes</p><p>✓ Gardez un cadrage stable</p></div>
   </div>
   <div className="footer-actions"><button className="ghost">← Retour</button><button className="gradient-btn">Suivant →</button></div>
 </section>
}

function Characters(){
 return <section><div className="page-title row-title"><div><h1>Mes personnages</h1><p>Gérez vos références de personnages 3D.</p></div><button className="gradient-btn">＋ Ajouter un personnage</button></div>
 <div className="character-grid">{characters.map((c,i)=><CharacterCard key={i} c={c}/>)}</div></section>
}
function CharacterCard({c,compact}){return <div className={"character-card card "+(compact?"compact":"")}><div className="char-img"><img src={c.img} alt={c.name}/><button>⋮</button></div><b>{c.name}</b><small>{c.refs} · {c.date}</small>{!compact&&<div className="char-actions"><button>Utiliser</button><button>♙</button><button>✎</button></div>}</div>}

function Videos(){
 return <section><div className="page-title"><h1>Mes vidéos</h1><p>Retrouvez toutes vos créations générées.</p></div>
 <div className="filters"><button className="active">Toutes</button><button>Terminées</button><button>En cours</button><button>Échecs</button><div className="search">⌕ Rechercher...</div></div>
 <div className="video-list card">{generations.map((g,i)=><div className="video-row" key={i}><img src={g.img} alt=""/><div className="grow"><b>{["Free Fire Action","Battle Royale","Montage 3D","Gaming Scene"][i]}</b><small>{g.title} · {g.time}</small></div><div className={"status "+g.status.toLowerCase().replace(" ","-")}>{g.status}</div><button className="round">▶</button><button className="round">↓</button></div>)}</div>
 </section>
}
function History(){
 return <section><div className="page-title"><h1>Historique des générations</h1><p>Suivez l'activité de votre studio.</p></div>
 <div className="filters"><div className="select">Tous les types⌄</div><div className="select">Tous les statuts⌄</div></div>
 <div className="table card"><div className="tr th"><span>Date</span><span>Type</span><span>Modèle</span><span>Statut</span><span>Crédits</span></div>{generations.map((g,i)=><div className="tr" key={i}><span>22 avr. 2025<br/><small>14:32</small></span><span>{g.title}</span><span>Seedance 2.0</span><span className={"status "+g.status.toLowerCase().replace(" ","-")}>{g.status}</span><span>{g.credits.replace(" crédits","")}</span></div>)}</div>
 </section>
}
function Credits(){
 const packs=[["Starter","50 crédits","4,99 $"],["Creator","150 crédits","12,99 $"],["Pro","500 crédits","39,99 $"],["Studio","1 500 crédits","99,99 $"]];
 return <section><div className="page-title"><h1>Crédits</h1><p>Gérez votre solde et vos achats.</p></div>
 <div className="credit-top card"><div><span>Votre solde</span><strong>◇ 125 crédits</strong></div><button className="gradient-btn">Acheter des crédits</button></div>
 <h3 className="section-label">Offres de crédits</h3><div className="packs">{packs.map((p,i)=><div className={"pack card "+(i===1?"featured":"")} key={i}><b>{p[0]}</b><strong>{p[1]}</strong><span>{p[2]}</span><button className="gradient-btn small">Choisir</button></div>)}</div>
 <h3 className="section-label">Historique des crédits</h3><Panel title="Dernières opérations"><GenerationRow g={{title:"Crédits ajoutés",status:"Terminé",credits:"+150 crédits",img:"/alpha.png",time:"22 avr. 2025 · Pack Creator"}}/><GenerationRow g={{title:"Crédits utilisés",status:"Terminé",credits:"-25 crédits",img:"/shadow.png",time:"22 avr. 2025 · Génération vidéo"}}/></Panel>
 </section>
}
function Settings(){
 return <section><div className="page-title"><h1>Paramètres</h1><p>Gérez votre profil et vos préférences.</p></div><div className="settings card"><aside><button className="active">♙ Profil</button><button>♙ Sécurité</button><button>⚙ Préférences</button><button>◇ Compte</button></aside><div className="settings-body"><h3>Profil</h3><div className="profile-head"><div className="avatar big">J</div><div><b>JoyBoy</b><small>Changer la photo</small></div></div><label>Nom<input value="JoyBoy" readOnly/></label><label>Email<input value="joyboy@example.com" readOnly/></label><button className="gradient-btn">Enregistrer</button></div></div></section>
}

createRoot(document.getElementById("root")).render(<App/>);