// AMICAL LABS video API contract.
// Keep BytePlus credentials on the server. The frontend only talks to /api/video/*.
export async function createCharacterReplacement(payload) {
  const response = await fetch("/api/video/replace-character", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!response.ok) throw new Error("Impossible de démarrer la génération.");
  return response.json();
}

export async function getGeneration(taskId) {
  const response = await fetch(`/api/video/generation/${encodeURIComponent(taskId)}`);
  if (!response.ok) throw new Error("Impossible de récupérer la génération.");
  return response.json();
}
