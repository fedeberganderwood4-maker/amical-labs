# AMICAL LABS API contract

## POST /api/video/replace-character

Request:
{
  "videoUrl": "public-or-storage-url",
  "characterId": "existing-character-id",
  "targetDescription": "description of the character to replace",
  "imageUrls": ["face-url", "back-url", "profile-url"],
  "instructions": "optional user instructions"
}

Server responsibilities:
- authenticate current user;
- verify ownership of the character/video;
- verify available credits;
- create a generation record with `processing` status;
- call BytePlus `las_video_edit_enhance`;
- return the task id;
- never expose BytePlus credentials.

## GET /api/video/generation/:taskId

Server responsibilities:
- poll BytePlus;
- normalize status to `queued | processing | completed | failed`;
- save the final video URL when completed;
- update the existing generation record;
- charge credits according to the product's existing credit policy;
- return normalized status to the frontend.
