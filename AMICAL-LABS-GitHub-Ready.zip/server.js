import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: '2mb' }));

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'amical-labs', byteplusConfigured: Boolean(process.env.BYTEPLUS_API_KEY) });
});

app.post('/api/video/replace-character', async (req, res) => {
  try {
    if (!process.env.BYTEPLUS_API_KEY) {
      return res.status(503).json({ error: 'BytePlus n’est pas encore configuré côté serveur.' });
    }
    const { videoUrl, imageUrls, instructions = '' } = req.body || {};
    if (!videoUrl || !Array.isArray(imageUrls) || imageUrls.length < 1) {
      return res.status(400).json({ error: 'videoUrl et au moins une image de référence sont requis.' });
    }

    const baseUrl = process.env.BYTEPLUS_BASE_URL || 'https://operator.las.ap-southeast-1.bytepluses.com';
    const payload = {
      operator_id: process.env.BYTEPLUS_OPERATOR_ID || 'las_video_edit_enhance',
      operator_version: process.env.BYTEPLUS_OPERATOR_VERSION || 'v1',
      data: {
        video_url: videoUrl,
        template: { id: 'replace/person_replace' },
        user_prompt: instructions || 'Fully replace the selected source character with the target character in the reference images. Preserve the source video motion, timing, position, interactions, camera work, composition, lighting, environment and background as much as possible.',
        image_urls: imageUrls,
        model: process.env.BYTEPLUS_MODEL || 'dreamina-seedance-2-5-260628',
      },
    };

    const r = await fetch(`${baseUrl}/api/v1/submit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.BYTEPLUS_API_KEY}` },
      body: JSON.stringify(payload),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) return res.status(r.status).json({ error: data?.metadata?.error_msg || data?.error || 'BytePlus submit failed.', details: data });
    return res.json(data);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'Erreur serveur.' });
  }
});

app.get('/api/video/generation/:taskId', async (req, res) => {
  try {
    if (!process.env.BYTEPLUS_API_KEY) return res.status(503).json({ error: 'BytePlus n’est pas encore configuré côté serveur.' });
    const baseUrl = process.env.BYTEPLUS_BASE_URL || 'https://operator.las.ap-southeast-1.bytepluses.com';
    const r = await fetch(`${baseUrl}/api/v1/poll`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.BYTEPLUS_API_KEY}` },
      body: JSON.stringify({
        operator_id: process.env.BYTEPLUS_OPERATOR_ID || 'las_video_edit_enhance',
        operator_version: process.env.BYTEPLUS_OPERATOR_VERSION || 'v1',
        task_id: req.params.taskId,
      }),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) return res.status(r.status).json({ error: data?.metadata?.error_msg || data?.error || 'BytePlus poll failed.', details: data });
    return res.json(data);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'Erreur serveur.' });
  }
});

const dist = path.join(__dirname, 'dist');
app.use(express.static(dist));
app.get(/.*/, (_req, res) => res.sendFile(path.join(dist, 'index.html')));

app.listen(port, () => console.log(`AMICAL LABS listening on ${port}`));
